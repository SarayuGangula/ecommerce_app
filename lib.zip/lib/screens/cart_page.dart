import 'package:flutter/material.dart';
import '../widgets/cart_item.dart';

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Mock cart items
    final cartItems = [
      {'name': 'Product 1', 'price': 20.0, 'quantity': 1},
      {'name': 'Product 2', 'price': 15.0, 'quantity': 2},
    ];

    double total = cartItems.fold(0, (sum, item) => sum + (item['price'] * item['quantity']));

    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                return CartItem(
                  name: cartItems[index]['name'],
                  price: cartItems[index]['price'],
                  quantity: cartItems[index]['quantity'],
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Total: \$${total.toStringAsFixed(2)}', style: TextStyle(fontSize: 20)),
          ),
          ElevatedButton(
            onPressed: () {
              // Proceed to checkout
            },
            child: Text('Checkout'),
          ),
        ],
      ),
    );
  }
}
