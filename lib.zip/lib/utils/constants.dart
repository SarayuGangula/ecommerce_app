const String baseUrl = 'https://example.com/api';
const double padding = 16.0;
